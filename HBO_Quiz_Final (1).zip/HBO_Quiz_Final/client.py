import socket
import json
import sys
import time


class QuizClient:
    def __init__(self, host='localhost', port=5555):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        try:
            self.client.connect((host, port))
        except ConnectionRefusedError:
            print("Kan geen verbinding maken met de server. Zorg dat de server eerst gestart is.")
            sys.exit(1)
            #29
    def speel_quiz(self):
        print("="*50)
        print("    WELKOM BIJ DE MULTIPLAYER QUIZ!")
        print("="*50)
        print("Typ 'quit' om de quiz te verlaten.")
        print("Bereid je voor op de strijd!")
        
        try:
            while True:
                data = self.client.recv(1024).decode()
                if not data:
                    break
                    
                try:
                    vraag = json.loads(data)
                    if "vraag" in vraag:
                        voortgang = ""
                        if "vraag_nummer" in vraag and "totaal_vragen" in vraag:
                            voortgang = f" ({vraag['vraag_nummer']}/{vraag['totaal_vragen']})"
                        
                        print("\n" + "="*50)
                        print(f"VRAAG{voortgang}:", vraag["vraag"])
                        print("="*50)
                        
                        if vraag["type"] == "ja/nee":
                            antwoord = self._krijg_input("Jouw antwoord (ja/nee): ", ['ja', 'nee'])
                        elif vraag["type"] == "meerkeuze":
                            antwoord = self._krijg_input("Jouw antwoord (a/b/c): ", ['a', 'b', 'c'])
                        else:  # open vraag #10
                            antwoord = input("\nJouw antwoord: ").lower().strip()
                            if antwoord == 'quit':
                                print("\nQuiz wordt afgesloten...")
                                return
                        
                        self.client.send(antwoord.encode())
                        
                except json.JSONDecodeError:
                    print(data)
                    
        except KeyboardInterrupt:
            print("\nQuiz wordt afgesloten...")
        except ConnectionResetError:
            print("\nVerbinding met server verbroken.")
        finally:
            self.client.close()
    
    def _krijg_input(self, prompt, geldige_opties):
        while True:
            antwoord = input(f"\n{prompt}").lower().strip()
            if antwoord == 'quit':
                print("\nQuiz wordt afgesloten...")
                self.client.close()
                sys.exit(0) #06
            if antwoord in geldige_opties:
                return antwoord
            print(f"Ongeldige input! Voer een van deze opties in: {', '.join(geldige_opties)}")

def main():
    try:
        client = QuizClient()
        client.speel_quiz()
    except Exception as e:
        print(f"\nEr is een fout opgetreden: {e}")

if __name__ == "__main__":
    main()