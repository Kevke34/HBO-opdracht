# 
import socket
# 
import threading
import json
import time
import signal
import sys

# Quiz vragen
quiz_vragen = [
    # 
    {
        "type": "ja/nee",
        "vraag": "Is Python een programmeertaal?",
        "antwoord": "ja"
    },
    {
        "type": "meerkeuze",
        "vraag": "Wat is een correct datatype in Python?\na) mengelmoes\nb) integer\nc) chocola",
        # 
        "antwoord": "b"
    },
    {
        "type": "open",
        "vraag": "Welke functie gebruik je om tekst te printen in Python?",
        "antwoord": "print"
    },
    {
        "type": "ja/nee",
        "vraag": "Wordt HTML gebruikt voor styling?",
        "antwoord": "nee"
    },
    {
        "type": "meerkeuze",
        "vraag": "Wat is een loop in programmeren?\na) Een herhaling\nb) Een fout\nc) Een kleur",
        "antwoord": "a"
    },
    {
        "type": "open",
        "vraag": "Welk symbool wordt gebruikt voor vermenigvuldigen in Python?",
        "antwoord": "*"
    },
    {
        "type": "ja/nee",
        "vraag": "Is een database nodig voor elke website?",
        "antwoord": "nee"
    },
    {
        "type": "meerkeuze",
        # 1
        "vraag": "Wat is een boolean?\na) Een getal\nb) Waar of niet waar\nc) Een tekst",
        "antwoord": "b"
    }
]
class QuizServer:
    def __init__(self, host='localhost', port=5555):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind((host, port))
        self.server.listen(2)
        
        self.spelers = []
        self.scores = {}
        self.huidige_vraag = 0
        self.antwoorden_ontvangen = 0
        self.lock = threading.Lock()
        self.quiz_bezig = False
        self.quiz_klaar = False
        self.threads = []
        self.actief = True
        
        # Registreer signal handler voor nette afsluiting
        signal.signal(signal.SIGINT, self.shutdown)
        
    def verstuur_vraag(self):
        if self.huidige_vraag < len(quiz_vragen):
            vraag = quiz_vragen[self.huidige_vraag]
            bericht = {
                "type": vraag["type"],
                "vraag": vraag["vraag"],
                "vraag_nummer": self.huidige_vraag + 1,
                # 3
                "totaal_vragen": len(quiz_vragen)
            }
            for speler in list(self.spelers):
                try:
                    speler.send(json.dumps(bericht).encode())
                except:
                    self.verwijder_speler(speler)

    def verstuur_eindscore(self):
        # Bereid scoreboard voor
        speler_scores = []
        for s, score in self.scores.items():
            speler_scores.append((score, s))
        # 2
        # Sorteer op score (hoogste eerst)
        speler_scores.sort(reverse=True, key=lambda x: x[0])
        
        for speler in list(self.spelers):
            try:
                eindscore = f"\n{'='*50}\n"
                eindscore += f"           EINDRESULTAAT\n"
                eindscore += f"{'='*50}\n\n"
                eindscore += f"Quiz is afgelopen! Jouw score: {self.scores[speler]} van de {len(quiz_vragen)}\n\n"
                eindscore += f"SCOREBOARD:\n"
                eindscore += f"{'-'*30}\n"
                
                # Voeg plaats, speler indicator en score toe
                for i, (score, s) in enumerate(speler_scores):
                    indicator = " <- JIJ" if s == speler else ""
                    eindscore += f"{i+1}. Speler {i+1}: {score}/{len(quiz_vragen)} punten{indicator}\n"
                
                eindscore += f"{'-'*30}\n"
                speler.send(eindscore.encode())
            except:
                self.verwijder_speler(speler)

    def verwijder_speler(self, speler):
        with self.lock:
            if speler in self.spelers:
                self.spelers.remove(speler)
                del self.scores[speler]
            try:
                speler.close()
            except:
                pass

    def handle_speler(self, speler, adres):
        try:
            with self.lock:
                self.spelers.append(speler)
                self.scores[speler] = 0
                
            speler.send("Welkom bij de quiz! Wacht op andere speler...\n".encode())
            
            # Wacht tot tweede speler zich aanmeldt
            while len(self.spelers) < 2 and self.actief:
                time.sleep(0.1)
            
            if not self.actief:
                return
                
            # Start quiz als we twee spelers hebben
            with self.lock:
                if not self.quiz_bezig and len(self.spelers) == 2:
                    self.quiz_bezig = True
                    time.sleep(0.5)
                    for s in list(self.spelers):
                        try:
                            s.send("\nQuiz start nu!\n\n".encode())
                        except:
                            self.verwijder_speler(s)
                    time.sleep(0.5)
                    self.verstuur_vraag()
            
            # Quiz loop
            while self.huidige_vraag < len(quiz_vragen) and self.actief:
                try:
                    antwoord = speler.recv(1024).decode().strip().lower()
                    if not antwoord:
                        break
                    
                    with self.lock:
                        vraag = quiz_vragen[self.huidige_vraag]
                        
                        # Check antwoord
                        if antwoord == vraag["antwoord"].lower():
                            self.scores[speler] += 1
                            speler.send("\nGoed! +1 punt\n".encode())
                        else:
                            speler.send(f"\nFout! Het juiste antwoord was: {vraag['antwoord']}\n".encode())
                        
                        # Stuur score en toon tussenstand
                        scoreboard = f"Je score: {self.scores[speler]} punten\n"
                        scoreboard += f"Tussenstand: "
                        
                        # Eenvoudige tussentijdse score voor alle spelers
                        for i, (s, score) in enumerate(self.scores.items()):
                            is_jij = " (jij)" if s == speler else ""
                            scoreboard += f"Speler {i+1}: {score}{is_jij}, "
                        
                        # Verwijder laatste komma en spatie
                        scoreboard = scoreboard[:-2] + "\n\n"
                        
                        speler.send(scoreboard.encode())
                        
                        # Volgende vraag als beide spelers hebben geantwoord
                        self.antwoorden_ontvangen += 1
                        if self.antwoorden_ontvangen == len(self.spelers):
                            self.huidige_vraag += 1
                            self.antwoorden_ontvangen = 0
                            time.sleep(0.5)
                            if self.huidige_vraag < len(quiz_vragen):
                                self.verstuur_vraag()
                            else:
                                self.quiz_klaar = True
                                self.verstuur_eindscore()
                        else:
                            speler.send("\nWachten op andere speler...\n".encode())
                
                except:
                    break
            
        except Exception as e:
            print(f"Fout met speler {adres}: {e}")
        finally:
            self.verwijder_speler(speler)

    def start(self):
        print("Server is gestart op poort 5555...")
        try:
            while self.actief:
                try:
                    self.server.settimeout(1.0)
                    speler, adres = self.server.accept()
                    thread = threading.Thread(target=self.handle_speler, args=(speler, adres))
                    thread.daemon = True
                    thread.start()
                    self.threads.append(thread)
                except socket.timeout:
                    continue
        finally:
            self.shutdown()

    def shutdown(self, *args):
        print("\nServer wordt afgesloten...")
        self.actief = False
        
        # Sluit alle verbindingen
        for speler in list(self.spelers):
            try:
                speler.send("Server sluit af. Verbinding verbroken.\n".encode())
                speler.close()
            except:
                pass
        
        try:
            self.server.close()
        except:
            pass
        
        # Wacht op threads
        for thread in self.threads:
            if thread.is_alive():
                thread.join(0.5)
        
        sys.exit(0)

if __name__ == "__main__":
    quiz = QuizServer()
    quiz.start()